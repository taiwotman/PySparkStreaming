import sys
import abc



class Algorithm(object):
    
    __metaclass__ = abc.ABCMeta
    
    def template_method(self):
        """Skeleton of operations to perform. DON'T override me.

        The Template Method defines a skeleton of an algorithm in an operation,
        and defers some steps to subclasses.
        """
        self.__desc_word_count()
        self.do_wordcount()
        self.do_sparkjob()

    def __desc_word_count(self):
        """Protected operation. DON'T override me."""
        print("Algorithm: Spark streaming based on Word Count\n")
        this_method_name = sys._getframe().f_code.co_name
        print('{}.{}'.format(self.__class__.__name__, this_method_name))

    @abc.abstractmethod
    def do_wordcount(self):
        """Primitive operation. You HAVE TO override me, I'm a placeholder."""
        pass

 
    def do_sparkjob(self):
        """Hook. You CAN override me, I'm NOT a placeholder."""
        pass
       
       
