import abc
from base import Algorithm
import pandas as pd

from pyspark.sql.functions import udf
from pyspark.sql.types import *
#
# streaming_word_count.py
#

# Import the necessary classes and create a local SparkContext and Streaming Contexts
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
import spark
import os

#suppress TF log-info messages - remove to display TF logs 
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

class WordCountAlgorithm(Algorithm):
    
    def do_wordcount(self):
            """Primitive operation. You HAVE TO override me, I'm a placeholder."""
            # Create Spark Context with two working threads (note, `local[2]`)
            sc = SparkContext( "local[2]", "NetworkWordCount")

            sc.setLogLevel("OFF")

            # log4jLogger = sc._jvm.org.apache.log4j 
            # log = log4jLogger.LogManager.getLogger(__name__) 
            # log.warn("Hello World!")

            # Create local StreamingContextwith batch interval of 1 second
            ssc = StreamingContext(sc, 1)

            # Create DStream that will connect to the stream of input lines from connection to localhost:9999
            lines = ssc.socketTextStream("localhost", 9999)

            # Split lines into words
            words = lines.flatMap(lambda line: line.split(" "))

            # Count each word in each batch
            pairs = words.map(lambda word: (word, 1))
            wordCounts = pairs.reduceByKey(lambda x, y: x + y)

            # Print the first ten elements of each RDD generated in this DStream to the console
            wordCounts.pprint()

             # Start the computation
            ssc.start()

            # Wait for the computation to terminate
            ssc.awaitTermination()
        


    
    def do_sparkjob(self): 
       pass

        
       
    
            
         